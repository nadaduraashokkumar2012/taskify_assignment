// src/components/TaskFilter.tsx
import React, { useState } from 'react';

interface TaskFilterProps {
  onFilterChange: (status: string, priority: string) => void;
}

const TaskFilter: React.FC<TaskFilterProps> = ({ onFilterChange }) => {
  const [status, setStatus] = useState('all');
  const [priority, setPriority] = useState('all');

  const handleFilterChange = () => {
    // Pass the current values of status and priority to the parent
    onFilterChange(status, priority);
  };

  return (
    <div>
      <select
        value={status}
        onChange={(e) => setStatus(e.target.value)}
        onBlur={handleFilterChange}
      >
        <option value="all">All Status</option>
        <option value="pending">Pending</option>
        <option value="in-progress">In Progress</option>
        <option value="completed">Completed</option>
      </select>

      <select
        value={priority}
        onChange={(e) => setPriority(e.target.value)}
        onBlur={handleFilterChange}
      >
        <option value="all">All Priority</option>
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
    </div>
  );
};

export default TaskFilter;
