import React, { useState } from 'react';
import { Task } from '../types';

interface TaskFormProps {
  task?: Task; // Optional task for editing
  onSave: (task: Task) => void; // Function to handle save
}

const TaskForm: React.FC<TaskFormProps> = ({ onSave }) => {
  const [formTask, setFormTask] = useState<Task>(
     { title: 'test', description: 'testing', status: 'pending', priority: 'low' }
  );

  // Handle input changes
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormTask((prevTask) => ({
      ...prevTask,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formTask); // Pass the formTask to the parent component onSave handler
  };

  return (
    <form onSubmit={handleSubmit}>
        <div>
      <input
        type="text"
        name="title"
        value={formTask.title}
        onChange={handleChange}
        placeholder="Title"
      />
      </div>
      <div>
      <textarea
        name="description"
        value={formTask.description}
        onChange={handleChange}
        placeholder="Description"
      />
        </div>
        <div>
      <select
        name="status"
        value={formTask.status}
        onChange={handleChange}
      >
        <option value="pending">Pending</option>
        <option value="in-progress">In Progress</option>
        <option value="completed">Completed</option>
      </select>
      </div>
      <div>
      <select
        name="priority"
        value={formTask.priority}
        onChange={handleChange}
      >
        <option value="low">Low</option>
        <option value="medium">Medium</option>
        <option value="high">High</option>
      </select>
      </div>
      <button type="submit">Save</button>
    </form>
  );
};

export default TaskForm;
