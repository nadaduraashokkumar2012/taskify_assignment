// src/components/TaskDetails.tsx
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom'; // useNavigate for v6
import axios from 'axios';
import { Task } from '../types'; // Import the Task type
import TaskForm from './TaskForm';

const TaskDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>(); // Extracting the task ID from the URL
  const [task, setTask] = useState<Task | null>(null);
  const navigate = useNavigate(); // Using useNavigate instead of useHistory

  // Fetch the task data when the component mounts
  useEffect(() => {
    if (id) {
      axios.get(`/api/tasks/${id}`).then((response) => setTask(response.data));
    }
  }, [id]);

  const handleSave = (task: Task) => {
    // Update the task if it has an ID
    axios
      .put(`/api/tasks/${task.id}`, task)
      .then(() => navigate('/')); // Navigate to the homepage after saving
  };

  if (!task) return <div>Loading...</div>;

  return (
    <div>
      <h1>Edit Task</h1>
      <TaskForm task={task} onSave={handleSave} />
    </div>
  );
};

export default TaskDetails;
