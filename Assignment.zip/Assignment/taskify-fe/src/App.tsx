import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'; // Correct imports
import axios from 'axios';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import TaskDetails from './components/TaskDetails';
import { Task } from './types'; // Import the Task type

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    axios.get('http://localhost:5000/taskify/api/tasks').then((response) => setTasks(response.data));
  }, []);

  const handleSave = (task: Task) => {
    if (task.id) {
      // Update existing task
      axios.put(`http://localhost:5000/taskify/api/tasks/${task.id}`, task).then(() => {
        const updatedTasks = tasks.map((t) => (t.id === task.id ? task : t));
        setTasks(updatedTasks);
      });
    } else {
      // Add new task
      axios.post('http://localhost:5000/taskify/api/tasks', task).then((response) => {
        setTasks([...tasks, response.data]);
      });
    }
  };

  return (
    <Router>
      <div>
        <nav>
          <Link to="/">Home</Link> | 
          <Link to="/tasks/new">Add Task</Link>
        </nav>
        <Routes>
          <Route path="/" element={<TaskList tasks={tasks} />} />
          <Route path="/tasks/new" element={<TaskForm onSave={handleSave} />} />
          <Route path="/tasks/:id" element={<TaskDetails />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
