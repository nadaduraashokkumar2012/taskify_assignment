// src/routes/taskRoutes.ts
import { Router } from 'express';
import { createTask, getTasks, getTaskById, updateTask, deleteTask } from '../controllers/taskController';
import authenticateUser from '../middlewares/authMiddleware';

const router = Router();

// Protect the createTask route with authentication
router.get('/tasks', getTasks);

//router.post('/tasks/create', authenticateUser, createTask);

// Backend testing api purpose remove authenticateUser
router.post('/tasks/create', createTask);

router.get('/tasks/:id', getTaskById);

router.put('/tasks/:id', updateTask);

router.delete('/tasks/:id', deleteTask);

export default router;
