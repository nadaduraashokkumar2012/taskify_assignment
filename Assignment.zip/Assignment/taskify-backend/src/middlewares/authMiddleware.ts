// src/middlewares/authMiddleware.ts
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

// Secret key for JWT (in a real application, keep this in your .env file)
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

interface AuthRequest extends Request {
  userId?: string;
}

const authenticateUser = (req: AuthRequest, res: Response, next: NextFunction) :any=> {
  const token = req.headers['authorization']?.split(' ')[1]; // Bearer token

  if (!token) {
    return res.status(401).json({ message: 'No token, authorization denied' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    req.userId = decoded.userId; // Attach userId to the request object
    next(); // Call next() to pass control to the next middleware or route handler
  } catch (error) {
    return res.status(401).json({ message: 'Token is not valid' });
  }
};

export default authenticateUser;


