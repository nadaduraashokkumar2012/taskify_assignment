import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();


// Get the MongoDB URI from the environment variables
const dbUri = process.env.MONGO_URI;

if (!dbUri) {
  console.error('Database URI is not defined in the environment variables.');
  process.exit(1); // Exit the application if DB_URI is not defined
}

const connectDB = async () => {
  try {
    console.log('---process--',process.env.MONGO_URI)
    await mongoose.connect(process.env.MONGO_URI as string);
    console.log('MongoDB connected');
  } catch (error:any) {
    console.error('Database connection failed:', error.message);
    process.exit(1);
  }
};

export default connectDB;
