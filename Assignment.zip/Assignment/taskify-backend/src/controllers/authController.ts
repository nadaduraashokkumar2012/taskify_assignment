// src/controllers/authController.ts
import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// User login route (just a mock example, you'd typically check credentials against a database)
export const login = (req: Request, res: Response): void => {
  const { username, password } = req.body;

  // Dummy check for user (in a real application, check against a database)
  if (username === 'admin' && password === 'password') {
    const payload = { userId: 'testuser' }; // Mock userId, typically you would fetch it from the DB
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '2h' });

    res.json({ message: 'Login successful', token });
  } else {
    res.status(401).json({ message: 'Invalid credentials' });
  }
};


