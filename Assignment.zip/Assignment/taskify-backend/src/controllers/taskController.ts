// src/controllers/taskController.ts
import { Request, Response } from 'express';
import Task, { ITask } from '../models/task';

// Create a new task
export const createTask = async (req: Request, res: Response): Promise<void> => {
  try {
    const { title, description, dueDate, priority, status } = req.body;
    const task = new Task({ title, description, dueDate, priority, status });
    await task.save();
    res.status(201).json({ message: 'Task created successfully', task });
  } catch (error:any) {
    res.status(500).json({ message: 'Error creating task', error: error.message });
  }
};

// Get all tasks
export const getTasks = async (req: Request, res: Response): Promise<void> => {
  try {

    const tasks: ITask[] = await Task.find();
    res.status(200).json(tasks);
  } catch (error:any) {
    res.status(500).json({ message: 'Error fetching tasks', error: error.message });
  }
};

// Get a specific task by ID
export const getTaskById = async (req: Request, res: Response): Promise<void> => {
  try {

    const task = await Task.findById(req.params.id);
    if (!task) {
      res.status(404).json({ message: 'Task not found' });
    } else {
      res.status(200).json(task);
    }
  } catch (error:any) {
    res.status(500).json({ message: 'Error fetching task', error: error.message });
  }
};

// Update a task
export const updateTask = async (req: Request, res: Response): Promise<void> => {
  try {

    const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!task) {
      res.status(404).json({ message: 'Task not found' });
    } else {
      res.status(200).json({ message: 'Task updated successfully', task });
    }
  } catch (error:any) {
    res.status(500).json({ message: 'Error updating task', error: error.message });
  }
};

// Delete a task
export const deleteTask = async (req: Request, res: Response): Promise<void> => {
  try {

    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) {
      res.status(404).json({ message: 'Task not found' });
    } else {
      res.status(200).json({ message: 'Task deleted successfully' });
    }
  } catch (error:any) {
    res.status(500).json({ message: 'Error deleting task', error: error.message });
  }
};
